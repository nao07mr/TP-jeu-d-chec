public class Position {
    private char column;  // La colonne de la position (caractère 'a' à 'h')
    private int row;  // La ligne de la position (entier de 1 à 8)

    // Constructeur
    public Position(char column, int row) {
        this.column = column;
        this.row = row;
    }

    // Méthode pour obtenir la colonne de la position
    public char getColumn() {
        return column;
    }

    // Méthode pour obtenir la ligne de la position
    public int getRow() {
        return row;
    }

    // Méthode pour obtenir une représentation textuelle de la position (par exemple, "e4")
    public String toString() {
        return String.valueOf(column) + row;
    }
}
