public class King extends Piece {
    // Constructeur
    public King(Position position, int color) {
        super(position, color);
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        // Récupérer les positions de départ
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        // Récupérer les positions d'arrivée
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        // Calculer la différence entre les lignes et les colonnes
        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        // Un Roi peut se déplacer d'une case dans n'importe quelle direction
        return rowDiff <= 1 && colDiff <= 1;
    }

    @Override
    public String toString() {
        return "K"; // Représentation textuelle d'un Roi
    }
    @Override
    public String getPiece() {
        return "Roi"; // Retournez le type de pièce, ici "Roi".
    }
}