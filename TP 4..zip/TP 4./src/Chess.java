import java.util.Scanner;

public class Chess {
    private Cell[][] board;  // Le plateau d'échecs (tableau de cellules)
    private Player[] players;  // Les joueurs (blanc et noir)
    private Player currentPlayer;  // Le joueur actuel
    private String move;

    // Constructeur
    public Chess() {
        board = new Cell[8][8];  // Crée un plateau de 8x8 cellules
        players = new Player[2];  // Crée un tableau de joueurs pour blanc et noir
        currentPlayer = null;  // Pas de joueur actuel au départ
    }

    // Méthode pour démarrer une partie
    public void play() {
        createPlayers();
        initialiseBoard();
        while (!isCheckMate()) {
            printBoard();
            String move;
            do {
                move = askMove();
            } while (!isValidMove(move));
            updateBoard(move);
            switchPlayer();
        }
        System.out.println("Échec et mat. La partie est terminée.");
    }

    // Méthode pour initialiser les joueurs
    private void createPlayers() {
        players[0] = new Player("Blanc", 0);
        players[1] = new Player("Noir", 1);
        currentPlayer = players[0]; // Le joueur blanc commence
    }

    // Méthode pour initialiser le plateau
    private void initialiseBoard() {
        // Initialisation de tout le plateau
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                board[row][col] = new Cell(new Position((char) row, col));
            }
        }

        // Placez les pièces sur le plateau (vous devrez implémenter cela)
    }

    // Méthode pour afficher l'état actuel du plateau
    private void printBoard() {
        System.out.println("  a b c d e f g h"); // Colonne labels
        for (int row = 0; row < 8; row++) {
            System.out.print(8 - row + " "); // Numéros de rangée
            for (int col = 0; col < 8; col++) {
                Cell cell = board[row][col];
                if (cell.isEmpty()) {
                    System.out.print(". ");
                } else {
                    Piece piece = cell.getPiece();
                    System.out.print(piece.getSymbol() + " "); // Utilisez une méthode getSymbol pour obtenir le symbole de la pièce.
                }
            }
            System.out.println(8 - row); // Numéros de rangée à nouveau
        }
        System.out.println("  a b c d e f g h"); // Colonne labels
    }

    // Méthode pour demander au joueur son prochain coup
    private String askMove() {
        // Demandez au joueur en cours de saisir son prochain coup
        Scanner scanner = new Scanner(System.in);
        System.out.print(currentPlayer.getName() + ", saisissez votre coup : ");
        String move = scanner.nextLine();

        // Validez le format du coup (vous devrez implémenter la logique de validation ici)

        // Retournez le coup saisi
        return move;
    }

    // Méthode pour vérifier la validité d'un coup
    private boolean isValidMove(String move) {
        if (move.length() != 4) {
            System.out.println("Le format du coup est invalide. Utilisez le format : abcd (par exemple, e2e4).");
            return false;
        }

        char sourceCol = move.charAt(0);
        int sourceRow = Character.getNumericValue(move.charAt(1)) - 1;
        char destCol = move.charAt(2);
        int destRow = Character.getNumericValue(move.charAt(3)) - 1;

        if (sourceCol < 'a' || sourceCol > 'h' || destCol < 'a' || destCol > 'h' ||
                sourceRow < 0 || sourceRow > 7 || destRow < 0 || destRow > 7) {
            System.out.println("Les coordonnées du coup sont en dehors de la grille du plateau.");
            return false;
        }

        Cell sourceCell = board[7 - sourceRow][sourceCol - 'a'];
        Cell destCell = board[7 - destRow][destCol - 'a'];

        if (sourceCell.isEmpty()) {
            System.out.println("La case source est vide.");
            return false;
        }

        Piece piece = sourceCell.getPiece();
        Player player = players[piece.getColor()];

        if (player != currentPlayer) {
            System.out.println("Ce n'est pas votre tour.");
            return false;
        }

        if (!piece.isValidMove(sourceCell.getPosition(), destCell, board)) {
            System.out.println("Mouvement non valide pour cette pièce.");
            return false;
        }

        // Vous devrez également vérifier si le coup ne met pas le roi en échec, ce qui dépend de la situation actuelle.

        // Si toutes les vérifications passent, le coup est valide.
        return true;
    }

    // Méthode pour vérifier si un joueur est en échec et mat
    private boolean isCheckMate() {
        // Obtenez le roi du joueur en cours
        Piece king = null;
        for (Piece piece : players[currentPlayer.getColor()].getPieces()) {
            if (piece instanceof King) {
                king = piece;
                break;
            }
        }

        // Si le roi est en échec
        if (isInCheck(king.getPosition(), currentPlayer)) {
            // Parcourez toutes les pièces du joueur en cours
            for (Piece piece : players[currentPlayer.getColor()].getPieces()) {
                // Essayez chaque mouvement possible pour chaque pièce
                for (int row = 0; row < 8; row++) {
                    for (int col = 0; col < 8; col++) {
                        Position dest = new Position(7 - row, col);
                        if (piece.isValidMove(piece.getPosition(), board[7 - row][col], board)) {
                            // Clonez l'état du plateau pour évaluer le mouvement
                            Cell[][] tempBoard = cloneBoard(board);
                            tempBoard[7 - piece.getPosition().getRow()][piece.getPosition().getCol()].setPiece(null);
                            tempBoard[7 - row][col].setPiece(piece);
                            piece.setPosition(dest);

                            // Si le roi n'est plus en échec après ce mouvement, ce n'est pas un échec et mat
                            if (!isInCheck(king.getPosition(), currentPlayer)) {
                                return false;
                            }

                            // Remettez l'état du plateau comme avant pour explorer d'autres mouvements
                            piece.setPosition(piece.getPosition());
                            tempBoard[7 - row][col].setPiece(null);
                            tempBoard[7 - piece.getPosition().getRow()][piece.getPosition().getCol()].setPiece(piece);
                        }
                    }
                }
            }
            return true;  // Si aucun mouvement possible n'a résolu l'échec, c'est un échec et mat
        }

        return false;  // Si le roi n'est pas en échec, ce n'est pas un échec et mat
    }
    // Méthode pour vérifier si le roi est en échec
    private boolean isInCheck(Position kingPosition, Player player) {
        // Parcourez toutes les pièces du joueur adverse (l'autre joueur)
        Player opponent = (player == players[0]) ? players[1] : players[0];

        for (Piece piece : opponent.getPieces()) {
            if (piece.isValidMove(piece.getPosition(), kingPosition, board)) {
                return true; // Le roi est menacé par au moins une pièce adverse
            }
        }

        return false; // Le roi n'est pas menacé par les pièces adverses
    }


    // Méthode pour cloner l'état du plateau
    private Cell[][] cloneBoard(Cell[][] source) {
        Cell[][] copy = new Cell[8][8];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                copy[row][col] = new Cell(source[row][col]);
            }
        }
        return copy;
    }


    // Méthode pour passer au joueur suivant
    private void switchPlayer() {
        if (currentPlayer == players[0]) {
            currentPlayer = players[1];
        } else {
            currentPlayer = players[0];
        }
    }

    // Méthode pour metre à jour le plateau après un coup
    private void updateBoard(String move) {
        this.move = move;
        String[] parts = move.split(" ");

        if (parts.length != 2) {
            System.out.println("Format de coup invalide. Utilisez le format 'position source' 'position destination'.");
            return;
        }

        String sourcePosition = parts[0];
        String destinationPosition = parts[1];

        Position source = parsePosition(sourcePosition);
        Position destination = parsePosition(destinationPosition);

        Cell sourceCell = board[source.getRow()][source.getCol()];
        Cell destinationCell = board[destination.getRow()][destination.getCol()];

        if (sourceCell.isEmpty()) {
            System.out.println("La case source est vide.");
            return;
        }

        Piece piece = sourceCell.getPiece();
        Player player = players[piece.getColor()];

        if (player != currentPlayer) {
            System.out.println("Ce n'est pas votre tour.");
            return;
        }

        if (piece.isValidMove(source, destinationCell, board)) {
            // Effectuez le déplacement
            destinationCell.setPiece(piece);
            destinationCell.getPiece().setPosition(destination);
            sourceCell.setPiece(null);

            // Gérez les mouvements spéciaux ici (par exemple, le roque)

            // Passez au joueur suivant
            switchPlayer();
        } else {
            System.out.println("Mouvement non valide pour cette pièce.");
        }
    }

    // Méthode pour analyser la position (ex: 'e2' -> ligne 1, colonne 4)
    private Position parsePosition(String position) {
        char col = position.charAt(0);
        int row = Character.getNumericValue(position.charAt(1)) - 1;
        int colIndex = col - 'a';
        return new Position(row, colIndex);
    }
}