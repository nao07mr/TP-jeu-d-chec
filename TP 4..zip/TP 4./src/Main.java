public class Main {
    public static void main(String[] args) {
        Chess chess = new Chess();  // Crée un objet Chess
        chess.play();  // Lance la partie d'échecs
    }
}
