public class Queen extends Piece {

    public Queen(Position position, int color) {
        super(position, color);
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        // Déplacement horizontal ou vertical
        if (rowDiff == 0 || colDiff == 0) {
            return isPathClear(startRow, startColumn, endRow, endColumn, board);
        }

        // Déplacement en diagonale
        if (rowDiff == colDiff) {
            return isPathClear(startRow, startColumn, endRow, endColumn, board);
        }

        return false; // Déplacement invalide pour une Reine
    }

    @Override
    public String toString() {
        return "Q"; // Représentation textuelle d'une Reine
    }
    @Override
    public String getPiece() {
        return "Reine"; // Retournez le type de pièce, ici "Reine".
    }

    private boolean isPathClear(int startRow, char startColumn, int endRow, char endColumn, Cell[][] board) {
        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        int rowDirection = Integer.compare(endRow, startRow);
        int colDirection = Integer.compare(endColumn, startColumn);

        int currentRow = startRow + rowDirection;
        char currentColumn = startColumn;

        for (int i = 1; i < rowDiff; i++) {
            currentRow += rowDirection;
            currentColumn += colDirection;

            if (board[currentRow][currentColumn].getClass() != null) {
                return false; // Il y a une pièce sur le chemin
            }
        }

        return true; // Le chemin est libre
    }
}
