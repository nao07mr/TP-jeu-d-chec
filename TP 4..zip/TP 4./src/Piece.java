public abstract class Piece {
    // On note la visibilite des attributs definies a protected
    protected Position position;
    protected int color;
    public abstract boolean isValidMove(Postion position, Cell[][] board);
    public abstract String toString();
}
