public class Rook extends Piece {

    public Rook(Position position, int color) {
        super(position, color);
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        // Déplacement horizontal ou vertical
        return (rowDiff == 0 && colDiff > 0) || (rowDiff > 0 && colDiff == 0);
    }

    @Override
    public String toString() {
        return "R"; // Représentation textuelle d'une Tour
    }
    @Override
    public String getPiece() {
        return "Tour"; // Retournez le type de pièce, ici "Tour".
    }
}