public class Knight extends Piece {
    // Constructeur
    public Knight(Position position, int color) {
        super(position, color);
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        // Récupérer les positions de départ
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        // Récupérer les positions d'arrivée
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        // Calculer les différences en lignes et en colonnes
        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        // Un Cavalier peut se déplacer en "L"
        return (rowDiff == 2 && colDiff == 1) || (rowDiff == 1 && colDiff == 2);
    }

    @Override
    public String toString() {
        return "N"; // Représentation textuelle d'un Cavalier
    }
    @Override
    public String getPiece() {
        return "Cavalier"; // Retournez le type de pièce, ici "Cavalier".
    }
}