public class Cell {
    private final Position position;  // La position de la cellule (ligne et colonne)
    private boolean isEmpty;  // Indique si la cellule est vide
    private Piece currentPiece;  // La pièce actuellement sur la cellule (peut être null)

    // Constructeur
    public Cell(Position position) {
        this.position = position;
        this.isEmpty = isEmpty;
        this.currentPiece = null;  // Au départ, la cellule est vide
    }

    public Cell(Position position) {
    }

    // Méthode pour obtenir la position de la cellule
    public Position getPosition() {
        return position;
    }

    // Méthode pour vérifier si la cellule est vide
    public boolean isEmpty() {
        return isEmpty;
    }

    public void setPiece(boolean piece)
    {
        this.piece = piece;
    }

    private boolean piece;
    public boolean getPiece() {
        return piece;
    }
    // Méthode pour obtenir la pièce actuellement sur la cellule
    public Piece getCurrentPiece() {
        return currentPiece;
    }

    // Méthode pour placer une pièce sur la cellule
    public void setCurrentPiece(Piece piece) {
        this.currentPiece = piece;
        this.isEmpty = (piece == null);
    }

    // Méthode pour enlever la pièce de la cellule
    public void removePiece() {
        this.currentPiece = null;
        this.isEmpty = true;
    }
}
