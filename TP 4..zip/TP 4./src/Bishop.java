public class Bishop extends Piece {
    // Constructeur
    public Bishop(Position position, int color) {
        super(position, color);
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        // Récupérer les positions de départ
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        // Récupérer les positions d'arrivée
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        // Vérifier si le déplacement est diagonal
        int rowDiff = Math.abs(endRow - startRow);
        int colDiff = Math.abs(endColumn - startColumn);

        return rowDiff == colDiff;
    }

    @Override
    public String toString() {
        return "B"; // Représentation textuelle d'un Fou
    }
    @Override
    public String getPiece() {
        return "Fou";// Retournez le type de pièce, ici "Fou".
    }
}
