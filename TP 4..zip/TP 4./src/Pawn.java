public class Pawn extends Piece {
    private boolean firstMove; // Pour gérer le premier déplacement du pion

    // Constructeur
    public Pawn(Position position, int color) {
        super(position, color);
        firstMove = true;
    }

    @Override
    public boolean isValidMove(Position newPosition, Cell[][] board) {
        // Récupérer les positions de départ
        int startRow = position.getRow();
        char startColumn = position.getColumn();
        // Récupérer les positions d'arrivée
        int endRow = newPosition.getRow();
        char endColumn = newPosition.getColumn();

        // Calculer la différence en lignes
        int rowDiff = Math.abs(endRow - startRow);
        // Calculer la différence en colonnes
        int colDiff = Math.abs(endColumn - startColumn);

        // Le déplacement dépend de la couleur du pion
        if (color == 0) { // Blanc
            // Le premier déplacement peut être de deux cases en avant
            if (firstMove && rowDiff == 2 && colDiff == 0) {
                firstMove = false; // Le premier déplacement a eu lieu
                return true;
            }
            // Sinon, un déplacement d'une case vers l'avant est autorisé
            return rowDiff == 1 && colDiff == 0;
        } else { // Noir
            // Le premier déplacement peut être de deux cases en avant
            if (firstMove && rowDiff == 2 && colDiff == 0) {
                firstMove = false; // Le premier déplacement a eu lieu
                return true;
            }
            // Sinon, un déplacement d'une case vers l'avant est autorisé
            return rowDiff == 1 && colDiff == 0;
        }
    }

    @Override
    public String toString() {
        return "P"; // Représentation textuelle d'un Pion
    }
    @Override
    public String getPiece() {
        return "Pion"; // Retournez le type de pièce, ici "Pion".
    }
}
